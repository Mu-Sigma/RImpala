mvn clean install
