mvn clean install
mv RImpala-2.0.jar ../inst/java/RImpala-2.0.jar
